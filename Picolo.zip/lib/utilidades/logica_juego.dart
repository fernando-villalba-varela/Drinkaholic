import 'dart:math';
import '../modelos/jugador_modelo.dart';

class LogicaJuego {
  static int TragosBase = 1;
  
  static const List<String> prendasRopa = [
    "zapatos",
    "reloj",
    "anillos",
    "collar",
    "gorra",
    "lentes",
    "pulseras",
    "pendientes",
    "cinturón",
    "chaqueta",
  ];
  
  static const List<String> retos = [
    "Todos los jugadores que lleven {prenda} beben {tragos}",
    "Los jugadores con ojos {color} beben {tragos}",
    "Quien tenga el celular más viejo bebe {tragos}",
    "Los menores de {edad} años beben {tragos}",
    "Todos los que tengan hermanos beben {tragos}",
    "Los que hayan llegado último hoy beben {tragos}",
    "Quien tenga más seguidores en redes bebe {tragos}",
    "Los que estén solteros beben {tragos}",
    "Todos los jugadores de {signo} beben {tragos}",
    "Los que sepan tocar un instrumento beben {tragos}",
    "Quien tenga el cumpleaños más cercano bebe {tragos}",
    "Los zurdos beben {tragos}",
    "Todos los que practiquen deportes beben {tragos}",
    "Los que tengan tatuajes beben {tragos}",
    "Quien tenga más aplicaciones en el celular bebe {tragos}",
  ];

  static Jugador seleccionarJugador(List<Jugador> jugadores) {
    double pesoTotal =
        jugadores.fold(0, (suma, jugador) => suma + jugador.peso);
    double valorAleatorio = Random().nextDouble() * pesoTotal;
    Jugador? jugadorSeleccionado;

    for (var jugador in jugadores) {
      if (valorAleatorio < jugador.peso) {
        jugadorSeleccionado = jugador;
        break;
      }
      valorAleatorio -= jugador.peso;
    }

    jugadorSeleccionado ??= jugadores.first;
    _ajustarPesos(jugadorSeleccionado, jugadores);
    return jugadorSeleccionado;
  }

  static void _ajustarPesos(
      Jugador jugadorElegido, List<Jugador> todosLosJugadores) {
    for (var jugador in todosLosJugadores) {
      if (jugador.nombre == jugadorElegido.nombre) {
        // Asegura que el peso no sea menor que 1 después de restarle 5.
        jugador.peso = max(1.0, jugador.peso - 5.0);
      } else {
        jugador.peso += 5.0;
      }
    }
  }

  static void incrementarTragosBase(int rondaActual) {
    if (rondaActual >= 10 && Random().nextBool()) {
      TragosBase++;
    }
  }
  
  static String obtenerRetoAleatorio() {
    final random = Random();
    String reto = retos[random.nextInt(retos.length)];
    
    // Reemplazar placeholders con valores aleatorios
    if (reto.contains('{prenda}')) {
      final prenda = prendasRopa[random.nextInt(prendasRopa.length)];
      reto = reto.replaceAll('{prenda}', prenda);
    }
    
    if (reto.contains('{color}')) {
      final colores = ['marrones', 'azules', 'verdes', 'negros'];
      final color = colores[random.nextInt(colores.length)];
      reto = reto.replaceAll('{color}', color);
    }
    
    if (reto.contains('{edad}')) {
      final edad = 20 + random.nextInt(8); // 20-27 años
      reto = reto.replaceAll('{edad}', edad.toString());
    }
    
    if (reto.contains('{signo}')) {
      final signos = ['Aries', 'Tauro', 'Géminis', 'Cáncer', 'Leo', 'Virgo', 
                     'Libra', 'Escorpio', 'Sagitario', 'Capricornio', 'Acuario', 'Piscis'];
      final signo = signos[random.nextInt(signos.length)];
      reto = reto.replaceAll('{signo}', signo);
    }
    
    // Calcular tragos finales (multiplicador * TragosBase)
    final multiplier = 1 + random.nextInt(4);
    final tragosFinales = multiplier * TragosBase;
    
    // Usar forma singular o plural según el número
    final textoTragos = tragosFinales == 1 ? '$tragosFinales trago' : '$tragosFinales tragos';
    reto = reto.replaceAll('{tragos}', textoTragos);
    
    return reto;
  }
}
