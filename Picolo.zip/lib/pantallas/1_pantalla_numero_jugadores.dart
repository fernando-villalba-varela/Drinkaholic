import 'package:flutter/material.dart';
import '2_pantalla_nombres_jugadores.dart';

class PantallaNumeroJugadores extends StatefulWidget {
  const PantallaNumeroJugadores({super.key});

  @override
  State<PantallaNumeroJugadores> createState() =>
      _PantallaNumeroJugadoresState();
}

class _PantallaNumeroJugadoresState extends State<PantallaNumeroJugadores> {
  int _numeroJugadores = 2;

  void _incrementar() {
    setState(() {
      if (_numeroJugadores < 10) _numeroJugadores++;
    });
  }

  void _decrementar() {
    setState(() {
      if (_numeroJugadores > 2) _numeroJugadores--;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Configurar Partida'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text('¿Cuántos jugadores?', style: TextStyle(fontSize: 28)),
            const SizedBox(height: 30),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                IconButton(
                    icon: const Icon(Icons.remove),
                    iconSize: 40,
                    onPressed: _decrementar),
                const SizedBox(width: 20),
                Text('$_numeroJugadores',
                    style: const TextStyle(
                        fontSize: 60, fontWeight: FontWeight.bold)),
                const SizedBox(width: 20),
                IconButton(
                    icon: const Icon(Icons.add),
                    iconSize: 40,
                    onPressed: _incrementar),
              ],
            ),
            const SizedBox(height: 50),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 40, vertical: 15)),
              onPressed: () {
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (context) => PantallaNombresJugadores(
                        numeroJugadores: _numeroJugadores),
                  ),
                );
              },
              child: const Text('Continuar', style: TextStyle(fontSize: 20)),
            ),
          ],
        ),
      ),
    );
  }
}
