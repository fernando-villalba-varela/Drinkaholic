import 'package:flutter/material.dart';
import '../modelos/jugador_modelo.dart';
import '3_pantalla_juego.dart';

class PantallaNombresJugadores extends StatefulWidget {
  final int numeroJugadores;
  const PantallaNombresJugadores({super.key, required this.numeroJugadores});

  @override
  State<PantallaNombresJugadores> createState() =>
      _PantallaNombresJugadoresState();
}

class _PantallaNombresJugadoresState extends State<PantallaNombresJugadores> {
  late final List<TextEditingController> _controladores;
  final _formKey = GlobalKey<FormState>();

  @override
  void initState() {
    super.initState();
    _controladores = List.generate(
        widget.numeroJugadores, (index) => TextEditingController());
  }

  @override
  void dispose() {
    for (var controller in _controladores) {
      controller.dispose();
    }
    super.dispose();
  }

  void _iniciarJuego() {
    if (_formKey.currentState!.validate()) {
      final jugadores = _controladores.map((controlador) {
        return Jugador(nombre: controlador.text.trim());
      }).toList();

      Navigator.of(context).pushReplacement(
        MaterialPageRoute(
          builder: (context) => PantallaJuego(jugadores: jugadores),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Nombres de los Jugadores'),
      ),
      body: Form(
        key: _formKey,
        child: Column(
          children: [
            Expanded(
              child: ListView.builder(
                padding: const EdgeInsets.all(16.0),
                itemCount: widget.numeroJugadores,
                itemBuilder: (context, index) {
                  return Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8.0),
                    child: TextFormField(
                      controller: _controladores[index],
                      decoration: InputDecoration(
                        labelText: 'Jugador ${index + 1}',
                        border: const OutlineInputBorder(),
                      ),
                      validator: (value) {
                        if (value == null || value.trim().isEmpty) {
                          return 'Por favor, introduce un nombre';
                        }
                        return null;
                      },
                    ),
                  );
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  minimumSize: const Size(double.infinity, 50),
                ),
                onPressed: _iniciarJuego,
                child: const Text('¡Empezar a jugar!',
                    style: TextStyle(fontSize: 20)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
