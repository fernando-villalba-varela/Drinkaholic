import 'package:flutter/material.dart';
import '../modelos/jugador_modelo.dart';
import '../utilidades/logica_juego.dart';

class PantallaJuego extends StatefulWidget {
  final List<Jugador> jugadores;
  const PantallaJuego({super.key, required this.jugadores});

  @override
  State<PantallaJuego> createState() => _PantallaJuegoState();
}

class _PantallaJuegoState extends State<PantallaJuego> {
  int _ronda = 0;

  late Jugador _jugadorActual;
  late String _retoActual;

  @override
  void initState() {
    super.initState();
    _siguienteTurno();
  }

  void _siguienteTurno() {
    setState(() {
      _ronda++;
      // Incrementar TragosBase desde la ronda 10
      LogicaJuego.incrementarTragosBase(_ronda);
      _jugadorActual = LogicaJuego.seleccionarJugador(widget.jugadores);
      _retoActual = LogicaJuego.obtenerRetoAleatorio();
    });
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: _siguienteTurno,
      child: Scaffold(
        body: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  'Ronda $_ronda',
                  style: TextStyle(
                      fontSize: 24, color: Colors.white.withOpacity(0.7)),
                ),
                const SizedBox(height: 40),
                Text(
                  _jugadorActual.nombre,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 52,
                    fontWeight: FontWeight.bold,
                    color: Colors.tealAccent,
                  ),
                ),
                const SizedBox(height: 20),
                Text(
                  _retoActual,
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 28, height: 1.3),
                ),
                const Spacer(),
                const Text(
                  'Toca en cualquier lugar para continuar',
                  style: TextStyle(fontSize: 16, color: Colors.white38),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
