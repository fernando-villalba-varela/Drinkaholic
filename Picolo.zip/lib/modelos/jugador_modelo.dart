class Jugador {
  final String nombre;
  double peso;

  Jugador({required this.nombre, this.peso = 10.0});
}
